using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class GameBoard : MonoBehaviour
{

    [SerializeField]
    Tile tilePrefab = default;

    public Vector2Int psize;

    public Tile currentTitle;
    public void Initialize(Vector2Int size)
    {
        Debug.Log(size);
        this.psize = size;
        Vector2 offset = new Vector2(
            (size.x - 1) * 0.5f, (size.y - 1) * 0.5f
        );
        for (int y = 0; y < size.y; y++)
        {
            for (int x = 0; x < size.x; x++)
            {
                Tile tile = Instantiate(tilePrefab);
                tile.transform.SetParent(transform, false);
                tile.transform.localPosition = new Vector3(
                    x - offset.x, 0f, y - offset.y
                );
            }
        }
        //select one random tile near the middle
        int randomX = Random.Range(size.x / 3, 2 * size.x / 3); // Select a random X within the middle third
        int randomY = Random.Range(size.y / 3, 2 * size.y / 3); // Select a random Y within the middle third
        Tile selectedTile = transform.GetChild(randomX + randomY * size.x).GetComponent<Tile>(); // Get the tile at the random position
        //add castle script to selected tiel
        selectedTile.gameObject.AddComponent<Castle_empty>();
        selectedTile.GetComponent<Renderer>().material.color = Color.magenta;
        Destroy(selectedTile.GetComponent<MyClickableObject>());
    }

    private Tile CreateStart()
    {
        // Create a Path_temp from the center to the edge
        // Select a random edge tile
        Tile edgeTile = null;
        Debug.Log(psize);
        while (edgeTile == null)
        {
            int edge = Random.Range(0, 4); // Select a random edge (0 = left, 1 = right, 2 = bottom, 3 = top)
            switch (edge)
            {
                case 0: // Left edge
                    edgeTile = transform.GetChild(Random.Range(0, psize.y) * psize.x).GetComponent<Tile>();
                    break;
                case 1: // Right edge
                    edgeTile = transform.GetChild((Random.Range(0, psize.y) + 1) * psize.x - 1).GetComponent<Tile>();
                    break;
                case 2: // Bottom edge
                    edgeTile = transform.GetChild(Random.Range(0, psize.x)).GetComponent<Tile>();
                    break;
                case 3: // Top edge
                    edgeTile = transform.GetChild((psize.y - 1) * psize.x + Random.Range(0, psize.x)).GetComponent<Tile>();
                    break;
            }
        }
        edgeTile.GetComponent<Renderer>().material.color = Color.gray; // Color the edge tile gray
        edgeTile.gameObject.AddComponent<Path_temp>(); // Add Path_temp to the edge tile
        return edgeTile;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Tile nearestTile = null;
            Tile castleTile = GameObject.FindObjectOfType<Castle_empty>().GetComponentInParent<Tile>();
            if (castleTile == null)
            {
                Debug.LogError("Castle tile not found");
                return;
            }
            int counter =0;
            nearestTile = CreateStart();
            List<Tile> pathTiles = new List<Tile>();
            while (nearestTile != castleTile)
            {
                // Break condition
                counter ++;
                if (counter > 1000)
                {
                    break;
                }
                List<Tile> nearestTiles = GetAdjacentTiles(nearestTile);
                nearestTile.GetComponent<Renderer>().material.color = Color.gray;
                nearestTile.gameObject.AddComponent<Path_temp>();
                Destroy(nearestTile.GetComponent<MyClickableObject>());
                pathTiles.Add(nearestTile);
                if (pathTiles.Count(t => t == nearestTile) > 1)
                { // If a tile has more than 1 connected path
                    nearestTile.GetComponent<Renderer>().material.color = Color.white;
                    nearestTile.gameObject.AddComponent<MyClickableObject>();
                    Destroy(nearestTile.GetComponent<Path_temp>());
                    pathTiles.Remove(nearestTile); // Go one tile back
                    nearestTile = pathTiles.Last(); // Take next best option
                }
            }
            Tile[] tilesWithTempPath = FindObjectsOfType<Tile>().Where(tile => tile.GetComponent<Path_temp>() != null).ToArray();
            foreach (Tile tile in tilesWithTempPath)
            {
                tile.gameObject.AddComponent<Path_fin>();
                tile.GetComponent<Renderer>().material.color = Color.black;
                Destroy(tile.GetComponent<Path_temp>());
            }
        }
        if (Input.GetKeyDown(KeyCode.W))
        {
            Tile tileWithTempPath = FindObjectsOfType<Tile>().FirstOrDefault(tile => tile.GetComponent<Path_temp>() != null) ?? CreateStart();

            List<Tile> nextTile = GetAdjacentTiles(tileWithTempPath);
            tileWithTempPath.gameObject.AddComponent<Path_fin>();
            tileWithTempPath.GetComponent<Renderer>().material.color = Color.black;
            Destroy(tileWithTempPath.GetComponent<Path_temp>());

            nextTile[1].gameObject.AddComponent<Path_temp>();
            nextTile[1].GetComponent<Renderer>().material.color = Color.gray;
            Destroy(nextTile[1].GetComponent<MyClickableObject>());


        }
    }


    private List<Tile> GetAdjacentTiles(Tile tile)
    {
        List<Tile> adjacentTiles = new List<Tile>();
        Tile castleTile = GameObject.FindObjectOfType<Castle_empty>().GetComponentInParent<Tile>();

        float x = tile.transform.position.x;
        float z = tile.transform.position.z;

        // Check tile to the left
        if (x > 0)
        {
            Tile leftTile = GetTileAtPosition(new Vector2(x - 1, z));
            if (leftTile != null)
            {
                adjacentTiles.Add(leftTile);
                Debug.Log("Added left tile at position: " + (x - 1) + ", " + z);
            }
        }

        // Check tile to the right
        if (x < psize.x - 1)
        {
            Tile rightTile = GetTileAtPosition(new Vector2(x + 1, z));
            if (rightTile != null)
            {
                adjacentTiles.Add(rightTile);
                Debug.Log("Added right tile at position: " + (x + 1) + ", " + z);
            }
        }

        // Check tile below
        if (z > 0)
        {
            Tile bottomTile = GetTileAtPosition(new Vector2(x, z - 1));
            if (bottomTile != null)
            {
                adjacentTiles.Add(bottomTile);
                Debug.Log("Added bottom tile at position: " + x + ", " + (z - 1));
            }
        }

        // Check tile above
        if (z < psize.y - 1)
        {
            Tile topTile = GetTileAtPosition(new Vector2(x, z + 1));
            if (topTile != null && !topTile.GetComponent<Path_fin>())
            {
                adjacentTiles.Add(topTile);
                Debug.Log("Added top tile at position: " + x + ", " + (z + 1));
            }
        }

        Debug.Log("Total adjacent tiles found: " + adjacentTiles.Count);

        // Sort the tiles based on the level of MyClickableObject or distance to castle_empty
        adjacentTiles.Remove(null);
        adjacentTiles.RemoveAll(tile => tile.GetComponent<Path_fin>() != null);

        adjacentTiles = adjacentTiles.Where(tile => tile.GetComponent<Path_temp>() == null).ToList();
        Debug.Log(adjacentTiles.Count);
        if (adjacentTiles.Count < 2)
        {
            Debug.Log("Back one stap");
            return null;
        }

        List<Tile> orderedTiles = adjacentTiles
            .OrderBy(tile => tile.GetComponent<MyClickableObject>().level)
            .ThenBy(tile => Vector3.Distance(tile.transform.position, castleTile.transform.position))
            .ToList();
        return orderedTiles;
    }

    private Tile GetTileAtPosition(Vector2 position)
    {
        // Assuming tiles are children of this GameBoard object
        foreach (Transform child in transform)
        {
            Vector2 childPosition = new Vector2(child.position.x, child.position.z);
            if (childPosition == position)
            {
                Tile tile = child.GetComponent<Tile>();
                if (tile != null)
                {
                    Debug.Log("Tile found at position: " + position);
                    return tile;
                }
                else
                {
                    Debug.LogWarning("Tile component not found at position: " + position);
                }
            }
        }

        Debug.LogWarning("No tile found at position: " + position);
        return null;
    }


}
