using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tile : MonoBehaviour
{
    public int x;
    public int y;

    public bool walkable; // Is this node a valid path tile?

    public float gCost; // Distance from start node to this node
    public float hCost; // Heuristic estimate of distance to target node
    public float fCost; // Total cost (gCost + hCost)

    public Tile parent; // Reference to the previous node in the path

    public void Tiles(int x, int y, bool walkable)
    {
        this.x = x;
        this.y = y;
        this.walkable = walkable;
    }
}



